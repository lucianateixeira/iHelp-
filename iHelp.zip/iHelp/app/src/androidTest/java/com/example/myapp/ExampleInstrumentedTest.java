//IMPORTANT INFORMATION ABOUT THIS:
//When opening the project, Android will indicate an error here. I cpuld not resolve in time.
//To compile and run the application, simply right-click on the folder "java" and select the "Mark Directory as..."
//then "Umark as..."
//This will allow the application to run without any problems.




package com.example.myapp;

import android.content.Context;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    @Test
    public void useAppContext() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        assertEquals("com.example.myapp", appContext.getPackageName());
    }
}
