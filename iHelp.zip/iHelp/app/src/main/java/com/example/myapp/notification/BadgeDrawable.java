package com.example.myapp.notification;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import androidx.core.content.ContextCompat;

import com.example.myapp.R;

public class BadgeDrawable extends Drawable {

    private float dTextSize;
    private Paint dBadgePaint;
    private Paint dTextPaint;
    private Rect dTxtRect = new Rect();

    private String dCount = "";
    private boolean dWillDraw = false;

    public BadgeDrawable(Context context) {
        // mTextSize = 10dp;
        dTextSize = context.getResources().getDimension(R.dimen.text_size_small);

        dBadgePaint = new Paint();
        dBadgePaint.setColor(ContextCompat.getColor(context,R.color.colorAccent));
        dBadgePaint.setAntiAlias(true);
        dBadgePaint.setStyle(Paint.Style.FILL);

        dTextPaint = new Paint();
        dTextPaint.setColor(Color.WHITE);
        dTextPaint.setTypeface(Typeface.DEFAULT_BOLD);
        dTextPaint.setTextSize(dTextSize);
        dTextPaint.setAntiAlias(true);
        dTextPaint.setTextAlign(Paint.Align.CENTER);
    }

    @Override
    public void draw(Canvas canvas) {
        if (!dWillDraw) {
            return;
        }

        Rect bounds = getBounds();
        float width = bounds.right - bounds.left;
        float height = bounds.bottom - bounds.top;

        // Position the badge in the top-right quadrant of the icon.
        float radius = ((Math.min(width, height) / 2) - 1) / (float) 1.6;
        float centerX = width - radius - 1;
        float centerY = radius + 1;

        // Draw badge circle.
        canvas.drawCircle(centerX, centerY, radius, dBadgePaint);

        // Draw badge count text inside the circle.
        dTextPaint.getTextBounds(dCount, 0, dCount.length(), dTxtRect);
        float textHeight = dTxtRect.bottom - dTxtRect.top;
        float textY = centerY + (textHeight / 2f);
        canvas.drawText(dCount, centerX, textY, dTextPaint);
    }

    public void setCount(int count) {
        dCount = Integer.toString(count);


        dWillDraw = count > 0;
        invalidateSelf();
    }

    @Override
    public void setAlpha(int alpha) {
        // do nothing
    }

    @SuppressLint("WrongConstant")
    @Override
    public int getOpacity() {
        // TODO Auto-generated method stub
        return 0;
    }


    @Override
    public void setColorFilter(ColorFilter cf) {
        // TODO Auto-generated method stub

    }
}


