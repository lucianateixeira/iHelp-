package com.example.myapp.utility;

import java.util.ArrayList;

public class ImageUrlUtils {
    static ArrayList<String> savedforLaterImageUri = new ArrayList<>();
    static ArrayList<String> cartListImageUri = new ArrayList<>();

    public static String[] getImageUrls() {
        String[] urls = new String[] {
                //Professional URL photos
                "https://cdn.pixabay.com/photo/2016/03/09/09/22/workplace-1245776__340.jpg",
                "https://cdn.pixabay.com/photo/2015/01/08/18/29/entrepreneur-593358__340.jpg",
                "https://cdn.pixabay.com/photo/2015/01/08/18/30/entrepreneur-593378__340.jpg",
                "https://cdn.pixabay.com/photo/2016/04/20/08/21/entrepreneur-1340649__340.jpg",
                "https://cdn.pixabay.com/photo/2017/01/14/10/56/men-1979261__340.jpg",
                "https://cdn.pixabay.com/photo/2018/01/17/04/14/industry-3087393__340.jpg",
                "https://cdn.pixabay.com/photo/2017/08/26/10/13/construction-2682641__340.jpg",
                "https://cdn.pixabay.com/photo/2014/06/17/16/53/construction-370588__340.jpg",
                "https://cdn.pixabay.com/photo/2014/07/06/13/55/calculator-385506__340.jpg",
                "https://cdn.pixabay.com/photo/2017/09/25/17/38/chart-2785979__340.jpg",
                "https://cdn.pixabay.com/photo/2016/10/10/22/38/business-1730089__340.jpg",
                "https://image.shutterstock.com/image-photo/young-manager-presenting-whiteboard-his-260nw-519924262.jpg",
                "https://image.shutterstock.com/image-photo/developing-programming-coding-technologies-website-260nw-1016500210.jpg",
                "https://cdn.pixabay.com/photo/2015/05/28/14/38/ux-787980__340.jpg",
                "https://cdn.pixabay.com/photo/2015/04/12/16/33/hammer-719066__340.jpg",
                "https://cdn.pixabay.com/photo/2020/02/25/09/44/municipal-election-4878405__340.jpg",

                //Hobbies URL photos
                "https://image.shutterstock.com/image-photo/handsome-chef-pouring-olive-oil-260nw-607012154.jpg",
                "https://image.shutterstock.com/image-photo/girl-sculpts-clay-pot-closeup-260nw-538244488.jpg",
                "https://cdn.pixabay.com/photo/2018/02/04/09/09/brushes-3129361__340.jpg",
                "https://cdn.pixabay.com/photo/2016/01/19/18/02/photographers-1150033__340.jpg",
                "https://cdn.pixabay.com/photo/2019/11/20/11/15/needlework-4639828__340.jpg",
                "https://cdn.pixabay.com/photo/2020/04/30/18/38/hobby-5114150__340.jpg",
                "https://image.shutterstock.com/image-photo/make-artist-doing-professional-young-260nw-564674182.jpg",
                "https://cdn.pixabay.com/photo/2014/02/05/00/37/staging-258631__340.jpg",
                "https://cdn.pixabay.com/photo/2017/08/26/06/15/ballet-2682291__340.jpg",
                "https://cdn.pixabay.com/photo/2019/04/16/23/52/clown-4133113__340.jpg",
                "https://cdn.pixabay.com/photo/2020/02/11/21/09/bio-4840960__340.jpg",
                "https://image.shutterstock.com/image-photo/young-girl-learns-bake-cakes-260nw-275220242.jpg",
                "https://cdn.pixabay.com/photo/2015/05/31/11/18/table-791149__340.jpg",
                "https://cdn.pixabay.com/photo/2014/11/29/17/57/forge-550622__340.jpg",
                "https://cdn.pixabay.com/photo/2016/11/18/17/14/cloth-1835894__340.jpg",

                //School Help
                "https://image.shutterstock.com/image-photo/young-boy-doing-homework-during-260nw-1038798910.jpg",
                "https://image.shutterstock.com/image-photo/happy-family-mother-daughter-do-260nw-578885029.jpg",
                "https://image.shutterstock.com/image-photo/sign-language-teacher-extra-tutoring-260nw-1440992648.jpg",
                "https://cdn.pixabay.com/photo/2019/01/27/08/05/guitar-3957586__340.jpg",
                "https://cdn.pixabay.com/photo/2019/09/26/17/54/design-4506643__340.jpg",
                "https://cdn.pixabay.com/photo/2017/09/01/18/48/teach-2705131__340.jpg",
                "https://image.shutterstock.com/image-photo/asian-young-pianist-teacher-teaching-260nw-1243718176.jpg",
                "https://image.shutterstock.com/image-photo/cute-kids-singing-music-class-260nw-619805960.jpg",

                //Lifestyle URL photos
                "https://cdn.pixabay.com/photo/2018/01/01/01/56/yoga-3053488__340.jpg",
                "https://cdn.pixabay.com/photo/2020/02/15/00/33/yoga-4849681__340.jpg",
                "https://cdn.pixabay.com/photo/2016/11/09/20/53/yoga-1812695__340.jpg",
                "https://image.shutterstock.com/image-photo/surfer-on-blue-ocean-wave-260nw-145257634.jpg",
                "https://image.shutterstock.com/image-photo/surf-instructor-demonstrating-how-stand-260nw-663791812.jpg",
                "https://cdn.pixabay.com/photo/2019/08/26/23/23/surf-4433030__340.jpg",
                "https://cdn.pixabay.com/photo/2016/10/22/18/36/climbing-1761386__340.jpg",
                "https://cdn.pixabay.com/photo/2014/10/08/17/39/climbing-480459__340.jpg",
                "https://cdn.pixabay.com/photo/2017/09/06/20/35/massage-2722936__340.jpg",
                "https://cdn.pixabay.com/photo/2015/01/10/17/32/physiotherapy-595529__340.jpg",

                //Academic Help
                "https://cdn.pixabay.com/photo/2017/11/12/09/32/people-2941951__340.jpg",
                "https://image.shutterstock.com/image-photo/high-school-college-students-studying-260nw-770131126.jpg",
                "https://image.shutterstock.com/image-photo/mastest-thesis-being-written-on-260nw-1127552513.jpg",
                "https://image.shutterstock.com/image-photo/paper-stack-pile-unfinished-documents-260nw-778413115.jpg",
                "https://image.shutterstock.com/image-photo/man-stressed-while-working-on-260nw-796181494.jpg",
                "https://cdn.pixabay.com/photo/2018/01/17/07/06/laptop-3087585__340.jpg",
                "https://cdn.pixabay.com/photo/2019/04/10/20/09/books-4118058__340.jpg",
                "https://cdn.pixabay.com/photo/2017/08/30/17/26/analytics-2697949__340.jpg"
        };
        return urls;
    }

    public static String[] getProfessionalsUrls() {
        String[] urls = new String[]{
                //Professional URL photos
                "https://cdn.pixabay.com/photo/2016/03/09/09/22/workplace-1245776__340.jpg",
                "https://cdn.pixabay.com/photo/2015/01/08/18/29/entrepreneur-593358__340.jpg",
                "https://cdn.pixabay.com/photo/2015/01/08/18/30/entrepreneur-593378__340.jpg",
                "https://cdn.pixabay.com/photo/2016/04/20/08/21/entrepreneur-1340649__340.jpg",
                "https://cdn.pixabay.com/photo/2017/01/14/10/56/men-1979261__340.jpg",
                "https://cdn.pixabay.com/photo/2018/01/17/04/14/industry-3087393__340.jpg",
                "https://cdn.pixabay.com/photo/2017/08/26/10/13/construction-2682641__340.jpg",
                "https://cdn.pixabay.com/photo/2014/06/17/16/53/construction-370588__340.jpg",
                "https://cdn.pixabay.com/photo/2014/07/06/13/55/calculator-385506__340.jpg",
                "https://cdn.pixabay.com/photo/2017/09/25/17/38/chart-2785979__340.jpg",
                "https://cdn.pixabay.com/photo/2016/10/10/22/38/business-1730089__340.jpg",
                "https://image.shutterstock.com/image-photo/young-manager-presenting-whiteboard-his-260nw-519924262.jpg",
                "https://image.shutterstock.com/image-photo/developing-programming-coding-technologies-website-260nw-1016500210.jpg",
                "https://cdn.pixabay.com/photo/2015/05/28/14/38/ux-787980__340.jpg",
                "https://cdn.pixabay.com/photo/2015/04/12/16/33/hammer-719066__340.jpg",
                "https://cdn.pixabay.com/photo/2020/02/25/09/44/municipal-election-4878405__340.jpg"
        };
        return urls;
    }

    public static String[] getSchoolHelpUrls() {
        String[] urls = new String[]{
                //School Help
                "https://image.shutterstock.com/image-photo/young-boy-doing-homework-during-260nw-1038798910.jpg",
                "https://image.shutterstock.com/image-photo/happy-family-mother-daughter-do-260nw-578885029.jpg",
                "https://image.shutterstock.com/image-photo/sign-language-teacher-extra-tutoring-260nw-1440992648.jpg",
                "https://cdn.pixabay.com/photo/2019/01/27/08/05/guitar-3957586__340.jpg",
                "https://cdn.pixabay.com/photo/2019/09/26/17/54/design-4506643__340.jpg",
                "https://cdn.pixabay.com/photo/2017/09/01/18/48/teach-2705131__340.jpg",
                "https://image.shutterstock.com/image-photo/asian-young-pianist-teacher-teaching-260nw-1243718176.jpg",
                "https://image.shutterstock.com/image-photo/cute-kids-singing-music-class-260nw-619805960.jpg"

        };
        return urls;
    }

    public static String[] getHobbiesUrls() {
        String[] urls = new String[]{
                //Hobbies URL photos
                "https://image.shutterstock.com/image-photo/handsome-chef-pouring-olive-oil-260nw-607012154.jpg",
                "https://image.shutterstock.com/image-photo/girl-sculpts-clay-pot-closeup-260nw-538244488.jpg",
                "https://cdn.pixabay.com/photo/2018/02/04/09/09/brushes-3129361__340.jpg",
                "https://cdn.pixabay.com/photo/2016/01/19/18/02/photographers-1150033__340.jpg",
                "https://cdn.pixabay.com/photo/2019/11/20/11/15/needlework-4639828__340.jpg",
                "https://cdn.pixabay.com/photo/2020/04/30/18/38/hobby-5114150__340.jpg",
                "https://image.shutterstock.com/image-photo/make-artist-doing-professional-young-260nw-564674182.jpg",
                "https://cdn.pixabay.com/photo/2014/02/05/00/37/staging-258631__340.jpg",
                "https://cdn.pixabay.com/photo/2017/08/26/06/15/ballet-2682291__340.jpg",
                "https://cdn.pixabay.com/photo/2019/04/16/23/52/clown-4133113__340.jpg",
                "https://cdn.pixabay.com/photo/2020/02/11/21/09/bio-4840960__340.jpg",
                "https://image.shutterstock.com/image-photo/young-girl-learns-bake-cakes-260nw-275220242.jpg",
                "https://cdn.pixabay.com/photo/2015/05/31/11/18/table-791149__340.jpg",
                "https://cdn.pixabay.com/photo/2014/11/29/17/57/forge-550622__340.jpg",
                "https://cdn.pixabay.com/photo/2016/11/18/17/14/cloth-1835894__340.jpg"

        };
        return urls;
    }

    public static String[] getLifeStyleUrls() {
        String[] urls = new String[]{
                //Lifestyle URL photos
                "https://cdn.pixabay.com/photo/2018/01/01/01/56/yoga-3053488__340.jpg",
                "https://cdn.pixabay.com/photo/2020/02/15/00/33/yoga-4849681__340.jpg",
                "https://cdn.pixabay.com/photo/2016/11/09/20/53/yoga-1812695__340.jpg",
                "https://image.shutterstock.com/image-photo/surfer-on-blue-ocean-wave-260nw-145257634.jpg",
                "https://image.shutterstock.com/image-photo/surf-instructor-demonstrating-how-stand-260nw-663791812.jpg",
                "https://cdn.pixabay.com/photo/2019/08/26/23/23/surf-4433030__340.jpg",
                "https://cdn.pixabay.com/photo/2016/10/22/18/36/climbing-1761386__340.jpg",
                "https://cdn.pixabay.com/photo/2014/10/08/17/39/climbing-480459__340.jpg",
                "https://cdn.pixabay.com/photo/2017/09/06/20/35/massage-2722936__340.jpg",
                "https://cdn.pixabay.com/photo/2015/01/10/17/32/physiotherapy-595529__340.jpg"
        };
        return urls;
    }

    public static String[] getAcademicHelpUrls() {
        String[] urls = new String[]{
                "https://cdn.pixabay.com/photo/2017/11/12/09/32/people-2941951__340.jpg",
                "https://image.shutterstock.com/image-photo/high-school-college-students-studying-260nw-770131126.jpg",
                "https://image.shutterstock.com/image-photo/mastest-thesis-being-written-on-260nw-1127552513.jpg",
                "https://image.shutterstock.com/image-photo/paper-stack-pile-unfinished-documents-260nw-778413115.jpg",
                "https://image.shutterstock.com/image-photo/man-stressed-while-working-on-260nw-796181494.jpg",
                "https://cdn.pixabay.com/photo/2018/01/17/07/06/laptop-3087585__340.jpg",
                "https://cdn.pixabay.com/photo/2019/04/10/20/09/books-4118058__340.jpg",
                "https://cdn.pixabay.com/photo/2017/08/30/17/26/analytics-2697949__340.jpg"

        };
        return urls;
    }

    // Methods for Save for later
    public void addSavedforLaterImageUri(String savedforLaterImageUri) {
        this.savedforLaterImageUri.add(0,savedforLaterImageUri);
    }

    public void removeSavedforLaterImageUri(int position) {
        this.savedforLaterImageUri.remove(position);
    }

    public ArrayList<String> getSavedforLaterImageUri(){ return this.savedforLaterImageUri; }

    // Methods for Cart
    public void addCartListImageUri(String savedforLaterImageUri) {
        this.cartListImageUri.add(0,savedforLaterImageUri);
    }

    public void removeCartListImageUri(int position) {
        this.cartListImageUri.remove(position);
    }

    public ArrayList<String> getCartListImageUri(){ return this.cartListImageUri; }
}
