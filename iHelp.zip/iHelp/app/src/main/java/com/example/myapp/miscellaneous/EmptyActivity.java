package com.example.myapp.miscellaneous;

//Empty Class for some features that are not gonna be fully developed.

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.myapp.R;

public class EmptyActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_empty);
    }
}
