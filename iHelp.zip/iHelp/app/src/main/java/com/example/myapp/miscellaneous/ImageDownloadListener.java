package com.example.myapp.miscellaneous;

public interface ImageDownloadListener {
    void onUpdate(int progress);
}
