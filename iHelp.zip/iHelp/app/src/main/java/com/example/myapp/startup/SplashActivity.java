package com.example.myapp.startup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import com.example.myapp.R;

/** A splash screen is a screen that appears when you open the app on your mobile device.
 * It can also be called splash screen or start screen and it shows uo while your app is loading.
 * It's highly recommended by Google Material Designs as it's the user's first experience and an impressive first impression t
 * that strengthens the brand. When the loading is finished the user can access the contents and functions of the app.
 */

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //This code shows the logo of the app before opening the application
        //Needs to be modified in the Manifest as the first page to appear.
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), WelcomeActivity.class);
                startActivity(intent);
            }
        }, 1500L);
    }
}

